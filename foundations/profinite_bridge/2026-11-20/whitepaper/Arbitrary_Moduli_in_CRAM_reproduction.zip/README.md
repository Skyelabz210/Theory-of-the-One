# Arbitrary Moduli in CRAM reproduction files

Companion to the research white paper prepared for Anthony Diaz, version 1.0,
19 November 2026. The formatted PDF and editable DOCX are separate deliverables.

## Contents

- `manuscript/` contains the full Markdown manuscript with LaTeX equations and its exact compatibility diagram.
- `central_checks/` contains the reproducible 6,246,650-case integer sweep and its recorded result.
- `pinned_checks/` contains exact script copies from the reviewed NINE65 commit, their stdout/stderr receipts, and the dependent-sister result JSON.
- `manifest.json` gives source revision, original repository paths, byte counts, and SHA-256 digests for the supplied files.

## Reproduce the central sweep

Use Python 3.8 or later. The scripts use only the standard library. The recorded
central run used Python 3.12.14 and exact integer arithmetic.

From the extracted archive directory:

```sh
python3 central_checks/verify_arbitrary_moduli.py --output rerun_central_results.json
```

Expected counts are 641,600 arbitrary-anchor quotient queries, 962,400 direct
target projections, and 4,642,650 bounded residue-derived target projections.
The total is 6,246,650 with zero failures. The direct projection suite uses
the oracle Euclidean quotient; the bounded suite derives its temporary quotient
from source residues and a declared interval. The projection checks use the
sufficient quotient modulo b. Minimal quotient precision b/gcd(M,b) is established
by Theorem 2's algebraic proof in the manuscript.

The script's explicit validation remains active under Python optimization.
Runtime paths and Python version fields may differ in a fresh result; compare
the mathematical ranges, counts, and failure fields rather than requiring a
byte-identical rerun receipt.

## Reproduce the pinned supplementary checks

```sh
python3 pinned_checks/witness_arbitrary_moduli_claims.py
python3 pinned_checks/dependent_sister_probe.py --output rerun_dependent_sister_results.json
```

The arbitrary-moduli witness intentionally exhibits failures of older formulas
and verifies corrected formulas. Its exit-zero result is not a statement that
every historical claim passed. Read the named cases in its output.

The dependent-sister probe enumerates all 11,011 pairs for moduli 77 and 143,
finds 1,001 compatible pairs, checks 1,001 common-polynomial updates, and rejects
the deliberately mismatched update. Additional multiplicative-order and root
checks are included in that pinned script.

## Evidence boundaries

These are finite arithmetic checks. They are not a fresh Lean compilation, a
Rust integration run, a performance benchmark, or a cryptographic security
validation. The white paper separately identifies universal mathematical proofs,
maintained formal sources and matching historical receipts, and implementation
source-inspection findings.

The paper's GitHub citations are pinned. Drive references remain source links
subject to the reader's existing access. This archive does not contain copies
of the underlying Drive documents.
